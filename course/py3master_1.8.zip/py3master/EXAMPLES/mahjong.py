#!/usr/bin/env python

for i in range(0x1F300, 0x1f448):
    print(chr(i), end=' ')
