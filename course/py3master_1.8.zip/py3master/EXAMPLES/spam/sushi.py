#!/usr/bin/env python

from spam import logger

def sushi_warn():
    logger.warn("in sushi!")

